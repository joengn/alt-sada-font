ALT SADA TRIALS: Regular, Regular CHC
Trial version 1.006 · 23 November 2026
Designed by Joe Nguyen · Published by Studio Alt
hi@studioalt.work · https://studioalt.work

THIS IS A TRIAL. It is for testing and evaluation only (see EULA-Trial.txt). Any commercial use, publication,
or web, app, logo or broadcast use needs a commercial licence, available from studioalt.work.


WHAT'S INSIDE

  Fonts/OTF/AltSADATrials-Regular.otf             Static font, Regular (CFF outlines). Recommended for macOS and design apps.
  Fonts/OTF/AltSADATrials-RegularCHC.otf          Static font, Regular CHC (CFF outlines).
  Fonts/TTF/AltSADATrials-Regular.ttf             Static font, Regular (TrueType outlines).
  Fonts/TTF/AltSADATrials-RegularCHC.ttf          Static font, Regular CHC (TrueType outlines).
  Fonts/Variable/AltSADATrialsVF-Regular.ttf      Variable font, Regular, with a Width axis.
  Fonts/Variable/AltSADATrialsVF-RegularCHC.ttf   Variable font, Regular CHC, with a Width axis.
  EULA-Trial.txt                                  Trial licence. Read before use.
  FONTLOG.txt                                     Font details and version history.

For each style, install either the OTF or the TTF, not both: they share the same name. The two styles have
their own family names (Alt SADA Trials and Alt SADA Trials CHC) and can be installed together. The variable
fonts are named Alt SADA Trials VF and Alt SADA Trials VF CHC and can be installed alongside the static fonts.


ABOUT THE TYPEFACE

Alt SADA is a condensed, high-contrast display typeface of capitals, drawn for posters and headlines. It covers
A–Z, 0–9, basic punctuation and complete Vietnamese (all vowels with tone marks, and Đ). Typing in lowercase
produces capitals. The two styles share letters, figures, spacing and kerning and differ only in the accents:
Regular has the full Alt SADA accent set; Regular CHC uses Studio Alt's own CHC accent design.

Best used at display sizes, with capitals 32 px tall or more. For poster-tight setting, use about -20 tracking.


TABULAR FIGURES

Figures are proportional by default. For tables, prices, timetables and scores, switch on tabular figures so
every figure has the same width and columns line up:
  Figma: Type settings > Details > Numbers > Tabular figures.
  Adobe apps: OpenType panel > Tabular Lining.   CSS: font-variant-numeric: tabular-nums;


VARIABLE FONT: WIDTH AXIS (wdth)

  100    Regular / Regular CHC (default, most condensed)
  125    SemiExpanded
  150    Expanded
  181.8  Golden: the O is 1.618 times as tall as it is wide

The cap height stays the same at every Width value, so text boxes trimmed to cap height (Figma: Vertical trim,
Cap height to baseline) always fit the letters. Wider settings keep counter shapes, hairline-to-stem
relationships and accent placement. In Figma: select the text, open Type settings, then Variable font axes,
then Width.


INSTALLING

macOS: double-click the font, then Install Font in Font Book. Remove older versions first.
Windows: right-click the font, then Install (or Install for all users).
Restart design apps after installing.


Copyright (c) 2026 Joe Nguyen, Studio Alt. All rights reserved.
Alt SADA is a trademark of Joe Nguyen, Studio Alt.
